import subprocess
import attr

from ..exceptions import InvalidConfigError
from ..factory import target_factory
from ..protocol import BootstrapProtocol
from ..step import step
from .common import Driver
from ..util.managedfile import ManagedFile
from ..util.timeout import Timeout
from ..util.helper import processwrapper


@target_factory.reg_driver
@attr.s(eq=False)
class MXSUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        "loader": {"MXSUSBLoader", "NetworkMXSUSBLoader"},
    }

    image = attr.ib(default=None)

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('mxs-usb-loader')
        else:
            self.tool = 'mxs-usb-loader'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None):
        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        processwrapper.check_wrapped_output(
            self.loader, [self.tool, "0", mf.get_remote_path()],
            print_on_silent_log=True
        )


@target_factory.reg_driver
@attr.s(eq=False)
class IMXUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        "loader": {"IMXUSBLoader", "NetworkIMXUSBLoader", "MXSUSBLoader", "NetworkMXSUSBLoader"},
    }

    image = attr.ib(default=None)
    verify = attr.ib(default=True, validator=attr.validators.instance_of(bool))

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('imx-usb-loader')
        else:
            self.tool = 'imx-usb-loader'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None):
        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        command = [self.tool, "-p", str(self.loader.path)]
        if self.verify:
            command.append("-c")
        command.append(mf.get_remote_path())

        processwrapper.check_wrapped_output(
            self.loader, command,
            print_on_silent_log=True
        )


@target_factory.reg_driver
@attr.s(eq=False)
class RKUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        "loader": {"RKUSBLoader", "NetworkRKUSBLoader"},
    }

    image = attr.ib(default=None)
    usb_loader = attr.ib(default=None)

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('rk-usb-loader')
        else:
            self.tool = 'rk-usb-loader'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None):
        if self.target.env:
            usb_loader = self.target.env.config.get_image_path(self.usb_loader)
            mf = ManagedFile(usb_loader, self.loader)
            mf.sync_to_resource()

        timeout = Timeout(3.0)
        while True:
            try:
                processwrapper.check_wrapped_output(
                    self.loader,
                    [self.tool, 'db', mf.get_remote_path()],
                    print_on_silent_log=True
                )
                break
            except subprocess.CalledProcessError:
                if timeout.expired:
                    raise

        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        timeout = Timeout(3.0)
        while True:
            try:
                processwrapper.check_wrapped_output(
                    self.loader,
                    [self.tool, 'wl', '0x40', mf.get_remote_path()],
                    print_on_silent_log=True
                )
                break
            except subprocess.CalledProcessError:
                if timeout.expired:
                    raise


@target_factory.reg_driver
@attr.s(eq=False)
class UUUDriver(Driver, BootstrapProtocol):
    bindings = {
        "loader": {"IMXUSBLoader", "NetworkIMXUSBLoader", "MXSUSBLoader", "NetworkMXSUSBLoader"},
    }

    image = attr.ib(default=None)
    script = attr.ib(default='', validator=attr.validators.instance_of(str))

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('uuu-loader')
        else:
            self.tool = 'uuu-loader'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None):
        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        cmd = ['-b', self.script] if self.script else []

        processwrapper.check_wrapped_output(
            self.loader, [self.tool] + cmd + [mf.get_remote_path()],
            print_on_silent_log=True
        )


@target_factory.reg_driver
@attr.s(eq=False)
class BDIMXUSBDriver(Driver, BootstrapProtocol):
    """
    This is a Driver for the Boundary Devices imx_usb_loader available from
    https://github.com/boundarydevices/imx_usb_loader

    It supports loading the second stage bootloader to a SDP gadget implemented
    by the first stage bootloader in SRAM. Accordingly, the image to upload
    must be specified explicitly.
    """
    bindings = {
        "loader": {"IMXUSBLoader", "NetworkIMXUSBLoader"},
    }

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('imx_usb')
        else:
            self.tool = 'imx_usb'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename):
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        processwrapper.check_wrapped_output(
            self.loader, [
                self.tool,
                f"--bus={self.loader.busnum}",
                f"--device={self.loader.devnum}",
                mf.get_remote_path(),
            ],
            print_on_silent_log=True
        )


@target_factory.reg_driver
@attr.s(eq=False)
class SunxiUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        "loader": {"SunxiUSBLoader", "NetworkSunxiUSBLoader"},
    }

    loadaddr = attr.ib(validator=attr.validators.instance_of(int))
    image = attr.ib(default=None)

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('sunxi-fel')
        else:
            self.tool = 'sunxi-fel'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    def _run_tool(self, *part):
        """Run sunxi-fel against the loader's USB device

        Args:
            part: Arguments to pass to the tool
        """
        args = ['-d', '%s:%s' % (self.loader.busnum, self.loader.devnum)]
        cmd = [self.tool] + args + list(part)

        processwrapper.check_output(
            self.loader.command_prefix + cmd,
            print_on_silent_log=True
        )

    @staticmethod
    def _is_boot_image(filename):
        """Check whether a file is an image which the boot ROM can run

        Such an image starts with SPL, which has an eGON header. It may also
        contain U-Boot proper, e.g. u-boot-sunxi-with-spl.bin

        Args:
            filename (str): Path to the file

        Returns:
            bool: True if the file has an eGON header
        """
        with open(filename, 'rb') as inf:
            return inf.read(12)[4:] == b'eGON.BT0'

    @Driver.check_active
    @step(args=['filename', 'phase'])
    def load(self, filename=None, phase=None):
        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        if phase not in (None, 'spl', 'u-boot'):
            raise ValueError(f"Unknown phase '{phase}'")
        boot_image = phase is None and self._is_boot_image(filename)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        pathname = mf.get_remote_path()
        if phase == 'spl':
            self._run_tool('spl', pathname)
        elif boot_image:
            # SPL must set up DRAM before U-Boot proper can be written, so run
            # SPL, then write U-Boot proper and start it
            self._run_tool('uboot', pathname)
        else:
            self._run_tool('write', '%#x' % self.loadaddr, pathname)

    @Driver.check_active
    @step()
    def execute(self):
        """Start executing the loaded image at the load address"""
        self._run_tool('exe', '%#x' % self.loadaddr)


@target_factory.reg_driver
@attr.s(eq=False)
class TegraUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        'loader': {'TegraUSBLoader', 'NetworkTegraUSBLoader'},
    }

    loadaddr = attr.ib(validator=attr.validators.instance_of(int))
    image = attr.ib(default=None)
    bct_image = attr.ib(default='bct',
                        validator=attr.validators.instance_of(str))

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('tegrarcm')
        else:
            self.tool = 'tegrarcm'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None, phase=None):
        if not self.target.env:
            raise InvalidConfigError("TegraUSBDriver needs an environment to find the BCT image")
        if filename is None and self.image is not None:
            filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        pathname = mf.get_remote_path()
        bct = ManagedFile(self.target.env.config.get_image_path(self.bct_image),
                          self.loader)
        bct.sync_to_resource()
        args = [self.tool, '--bct=' + bct.get_remote_path(),
               f'--bootloader={pathname}',
               f'--loadaddr={self.loadaddr:#08x}',
               '--usb-port-path', self.loader.path]

        processwrapper.check_output(
            self.loader.command_prefix + args,
            print_on_silent_log=True
        )

    @Driver.check_active
    @step()
    def execute(self):
        """Nothing to do: the boot ROM runs each piece as it arrives"""


@target_factory.reg_driver
@attr.s(eq=False)
class SamsungUSBDriver(Driver, BootstrapProtocol):
    bindings = {
        'loader': {'SamsungUSBLoader', 'NetworkSamsungUSBLoader'},
    }

    bl1_loadaddr = attr.ib(validator=attr.validators.instance_of(int))
    spl_loadaddr = attr.ib(validator=attr.validators.instance_of(int))
    loadaddr = attr.ib(validator=attr.validators.instance_of(int))
    image = attr.ib(default=None)
    bl1_image = attr.ib(default='bl1',
                        validator=attr.validators.instance_of(str))

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        # FIXME make sure we always have an environment or config
        if self.target.env:
            self.tool = self.target.env.config.get_tool('smdk-usbdl')
        else:
            self.tool = 'smdk-usbdl'

    def on_activate(self):
        pass

    def on_deactivate(self):
        pass

    @Driver.check_active
    @step(args=['filename'])
    def load(self, filename=None, phase=None):
        if filename is None:
            if not self.target.env:
                raise InvalidConfigError("SamsungUSBDriver needs an environment when no filename is given")
            if phase == 'bl1':
                filename = self.target.env.config.get_image_path(self.bl1_image)
            elif self.image is not None:
                filename = self.target.env.config.get_image_path(self.image)
        mf = ManagedFile(filename, self.loader)
        mf.sync_to_resource()

        if phase == 'bl1':
            addr = self.bl1_loadaddr
        elif phase == 'spl':
            addr = self.spl_loadaddr
        elif phase in (None, 'u-boot'):
            addr = self.loadaddr
        else:
            raise ValueError(f"Unknown phase '{phase}'")
        pathname = mf.get_remote_path()

        args = [self.tool, '-a', f'{addr:x}',
                '-b', f'{self.loader.busnum:03d}',
                '-d', f'{self.loader.devnum:03d}',
                '-f', pathname]

        processwrapper.check_output(self.loader.command_prefix + args)

    @Driver.check_active
    @step()
    def execute(self):
        """Nothing to do: the boot ROM runs each piece as it arrives"""
