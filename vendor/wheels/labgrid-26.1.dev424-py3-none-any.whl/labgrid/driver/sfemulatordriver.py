import attr
from .common import Driver
from ..factory import target_factory
from ..step import step
from ..util.helper import processwrapper
from ..util.managedfile import ManagedFile

@target_factory.reg_driver
@attr.s(eq=False)
class SFEmulatorDriver(Driver):
    """Provides access to em100 features

    Args:
        bindings (dict): driver to use with
    """
    bindings = {
        'emul': {'SFEmulator', 'NetworkSFEmulator'},
    }

    def __attrs_post_init__(self):
        super().__attrs_post_init__()
        if self.target.env:
            self.tool = self.target.env.config.get_tool('em100')
        else:
            self.tool = 'em100'

    @Driver.check_active
    @step(title='write_image', args=['filename'])
    def write_image(self, filename):
        '''Write an image to the SPI-flash emulator

        Args:
            filename (str): Filename to write
        '''
        mf = ManagedFile(filename, self.emul)
        mf.sync_to_resource()
        cmd = self.emul.command_prefix + [
            self.tool,
            '--device', f'{self.emul.busnum}:{self.emul.devnum}',
            '-s',
            '-p', 'LOW',
            '-c', self.emul.chip,
            '-d', mf.get_remote_path(),
            '-r',
        ]

        processwrapper.check_output(cmd)
